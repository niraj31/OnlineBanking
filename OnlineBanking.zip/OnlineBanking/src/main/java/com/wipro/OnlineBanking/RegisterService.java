package com.wipro.OnlineBanking;
import java.util.List;

public interface RegisterService {
	Register createRegister(Register register);

    Register updateRegister(Register register);

    List < Register > getAllRegister();

    Register getRegisterById(String userid);

}
