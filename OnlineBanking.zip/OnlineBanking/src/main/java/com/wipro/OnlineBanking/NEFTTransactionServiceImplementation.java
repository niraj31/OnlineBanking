package com.wipro.OnlineBanking;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class NEFTTransactionServiceImplementation implements NEFTTransactionService{
	@Autowired
    private NEFTTransactionRepository NEFTTransactionRepository;

    @Override
    public NEFTTransaction createNEFTTransaction(NEFTTransaction NEFTTransaction) {
        return NEFTTransactionRepository.save(NEFTTransaction);
    }
    
    @Override
    public List < NEFTTransaction > getAllNEFTTransaction() {
        return this.NEFTTransactionRepository.findAll();
    }
    
    @Override
    public NEFTTransaction getNEFTTransactionById(String id) {

        Optional < NEFTTransaction > NEFTTransactionDb = this.NEFTTransactionRepository.findById(id);

        if (NEFTTransactionDb.isPresent()) {
            return NEFTTransactionDb.get();
        } 
        else {
            throw new ResourceNotFoundException("Record not found with id : " + id);
        }
    }
    
}
