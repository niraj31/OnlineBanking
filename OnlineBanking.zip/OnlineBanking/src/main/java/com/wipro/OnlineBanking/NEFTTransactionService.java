package com.wipro.OnlineBanking;

import java.util.List;

public interface NEFTTransactionService {
	NEFTTransaction createNEFTTransaction(NEFTTransaction NEFTTransaction);

    List < NEFTTransaction > getAllNEFTTransaction();

    NEFTTransaction getNEFTTransactionById(String id);
}
